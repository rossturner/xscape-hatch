// src/shared/constants.ts
var BLUESKY_HANDLE_REGEX = /@?([a-zA-Z0-9_-]+\.bsky\.social)/gi;
var SELECTORS = {
  article: "article",
  tweetText: '[data-testid="tweetText"]',
  userNameFallback: 'a[href^="/"]',
  profileUserName: '[data-testid="UserName"]'
};
var BLUESKY_API = {
  profileUrl: "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile",
  webProfileUrl: "https://bsky.app/profile"
};
var API_CACHE = {
  prefix: "xscape:api:",
  ttl: 24 * 60 * 60 * 1e3,
  // 24 hours
  maxEntries: 1e4
};
var OCR_CACHE = {
  prefix: "xscape:ocr:",
  ttl: 7 * 24 * 60 * 60 * 1e3,
  // 7 days
  maxEntries: 1e4
};
var MAPPING_CACHE = {
  prefix: "xscape:mapping:",
  maxEntries: 2e4
};
var BADGE_ATTR = "data-xscape-hatch";
var MESSAGE_TYPES = {
  VERIFY_HANDLE: "VERIFY_HANDLE",
  HANDLE_VERIFIED: "HANDLE_VERIFIED",
  OCR_INIT: "OCR_INIT",
  OCR_READY: "OCR_READY",
  OCR_PROCESS: "OCR_PROCESS",
  OCR_PROCESS_INTERNAL: "OCR_PROCESS_INTERNAL",
  OCR_RESULT: "OCR_RESULT",
  DEBUG_TOGGLE: "DEBUG_TOGGLE"
};

// src/shared/debug.ts
var STORAGE_KEY = "xscape:debug";
var debugEnabled = false;
async function initDebug() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  debugEnabled = result[STORAGE_KEY] === true;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      debugEnabled = changes[STORAGE_KEY].newValue === true;
      log("MSG", `Debug ${debugEnabled ? "enabled" : "disabled"}`);
    }
  });
}
function log(category, message, ...data) {
  if (!debugEnabled) return;
  const prefix = `[Xscape:${category}]`;
  if (data.length > 0) {
    console.log(prefix, message, ...data);
  } else {
    console.log(prefix, message);
  }
}
async function setDebugEnabled(enabled) {
  await chrome.storage.local.set({ [STORAGE_KEY]: enabled });
}
async function clearAllCaches() {
  const prefixes = ["xscape:api:", "xscape:ocr:", "xscape:mapping:"];
  const all = await chrome.storage.local.get(null);
  const keysToRemove = Object.keys(all).filter(
    (key) => prefixes.some((prefix) => key.startsWith(prefix))
  );
  if (keysToRemove.length > 0) {
    await chrome.storage.local.remove(keysToRemove);
  }
  return keysToRemove.length;
}
function exposeDebugGlobal() {
  if (typeof document === "undefined") return;
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("content/debug-page.js");
  script.type = "module";
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
  document.addEventListener("xscape-debug-set", ((event) => {
    setDebugEnabled(event.detail === true);
  }));
  document.addEventListener("xscape-debug-query", () => {
    console.log(`[Xscape] Debug is ${debugEnabled ? "ON" : "OFF"}`);
  });
  document.addEventListener("xscape-clear-caches", async () => {
    const count = await clearAllCaches();
    document.dispatchEvent(new CustomEvent("xscape-caches-cleared", { detail: count }));
  });
}

// src/content/dom-observer.ts
function createDOMObserver(onTweetFound2) {
  let debounceTimer = null;
  const processedArticles = /* @__PURE__ */ new WeakSet();
  let pendingMutations = [];
  function processArticle(article) {
    if (processedArticles.has(article)) return;
    processedArticles.add(article);
    const author = extractTweetAuthor(article);
    const handles = extractHandlesFromArticle(article);
    const images = extractImagesFromArticle(article);
    const handleElements = findHandleElements(article);
    if (author || handles.length > 0 || images.length > 0 || handleElements.length > 0) {
      log("DOM", `Article: @${author?.twitterHandle ?? "?"} | bsky:${handles.length} img:${images.length} handles:${handleElements.length}`);
      onTweetFound2({
        article,
        author,
        blueskyHandles: handles,
        twitterHandles: handleElements,
        images
      });
    }
  }
  function scanPage() {
    const articles = document.querySelectorAll(SELECTORS.article);
    log("DOM", `Initial page scan: found ${articles.length} articles`);
    articles.forEach(processArticle);
  }
  function handleMutations(mutations) {
    pendingMutations.push(...mutations);
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const toProcess = pendingMutations;
      pendingMutations = [];
      for (const mutation of toProcess) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              const element = node;
              if (element.matches?.(SELECTORS.article)) {
                processArticle(element);
              }
              element.querySelectorAll?.(SELECTORS.article).forEach(processArticle);
            }
          });
        }
      }
      document.querySelectorAll(SELECTORS.article).forEach((article) => {
        if (!processedArticles.has(article)) {
          processArticle(article);
        }
      });
    }, 150);
  }
  const observer = new MutationObserver(handleMutations);
  return {
    start() {
      scanPage();
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    },
    stop() {
      observer.disconnect();
      if (debounceTimer) clearTimeout(debounceTimer);
    }
  };
}
function extractTweetAuthor(article) {
  let isRetweet = false;
  let retweetedBy = null;
  const socialContext = article.querySelector('[data-testid="socialContext"]');
  if (socialContext) {
    const text = socialContext.textContent || "";
    if (text.includes("reposted") || text.includes("Retweeted")) {
      isRetweet = true;
      const retweeterLink = socialContext.querySelector('a[href^="/"]');
      if (retweeterLink) {
        const href = retweeterLink.getAttribute("href");
        if (href) {
          retweetedBy = href.slice(1).split("/")[0].split("?")[0];
        }
      }
    }
  }
  let twitterHandle = null;
  let handleTextLink = null;
  const userLinks = article.querySelectorAll('a[href^="/"]');
  for (const link of userLinks) {
    const href = link.getAttribute("href");
    if (!href) continue;
    const pathPart = href.slice(1).split("/")[0].split("?")[0];
    if (!pathPart || pathPart === "i" || pathPart === "search" || pathPart === "hashtag") {
      continue;
    }
    if (isRetweet && pathPart.toLowerCase() === retweetedBy?.toLowerCase()) {
      continue;
    }
    const text = (link.textContent || "").trim();
    if (text.startsWith("@") && /^@[a-zA-Z0-9_]{1,15}$/.test(text)) {
      return {
        twitterHandle: pathPart,
        authorElement: link,
        isRetweet,
        retweetedBy
      };
    }
    if (!twitterHandle && link.querySelector('img[src*="profile_images"]')) {
      twitterHandle = pathPart;
      handleTextLink = link;
    }
  }
  if (twitterHandle && handleTextLink) {
    return {
      twitterHandle,
      authorElement: handleTextLink,
      isRetweet,
      retweetedBy
    };
  }
  return null;
}
function extractHandlesFromArticle(article) {
  const text = article.textContent || "";
  const matches = text.matchAll(BLUESKY_HANDLE_REGEX);
  const handles = /* @__PURE__ */ new Set();
  for (const match of matches) {
    handles.add(match[1].toLowerCase());
  }
  return Array.from(handles);
}
function extractImagesFromArticle(article) {
  const images = article.querySelectorAll("img");
  const results = [];
  images.forEach((img) => {
    if (img.src && img.width > 100 && img.height > 100) {
      const isAvatar = img.closest('[data-testid="Tweet-User-Avatar"]') || img.src.includes("profile_images");
      const isMedia = img.src.includes("pbs.twimg.com/media/");
      if (!isAvatar && isMedia) {
        const url = normalizeTwitterImageUrl(img.src);
        if (url) {
          results.push({ url, element: img });
        }
      }
    }
  });
  return results;
}
function normalizeTwitterImageUrl(src) {
  try {
    const url = new URL(src);
    const format = url.searchParams.get("format");
    if (!format) {
      log("DOM", `Skipping image without format: ${src}`);
      return null;
    }
    url.searchParams.set("name", "large");
    const result = url.toString();
    log("DOM", `Normalized URL: format=${format}, name=${url.searchParams.get("name")}`);
    return result;
  } catch (e) {
    log("DOM", `URL parse error: ${e}`);
    return null;
  }
}
function findHandleElements(article) {
  const results = [];
  const links = article.querySelectorAll('a[href^="/"]');
  links.forEach((link) => {
    const text = link.textContent || "";
    const match = text.match(/^@([a-zA-Z0-9_]{1,15})$/);
    if (match && !link.closest(`[${BADGE_ATTR}]`)) {
      results.push({
        element: link,
        twitterHandle: match[1],
        inferredBluesky: `${match[1].toLowerCase()}.bsky.social`
      });
    }
  });
  return results;
}
function getImageAuthor(imageElement) {
  const imgLink = imageElement.closest('a[href*="/status/"]');
  const statusUrl = imgLink?.getAttribute("href");
  if (statusUrl) {
    const author = statusUrl.split("/")[1];
    if (author && author !== "i" && author !== "search") {
      return author;
    }
  }
  return null;
}
function extractProfileHeader() {
  const userNameEl = document.querySelector(SELECTORS.profileUserName);
  if (!userNameEl) return null;
  const spans = userNameEl.querySelectorAll("span");
  for (const span of spans) {
    const text = span.textContent || "";
    const match = text.match(/^@([a-zA-Z0-9_]{1,15})$/);
    if (match && !span.closest(`[${BADGE_ATTR}]`)) {
      return {
        twitterHandle: match[1],
        handleElement: span
      };
    }
  }
  return null;
}
function isProfilePage() {
  const path = window.location.pathname;
  const parts = path.split("/").filter(Boolean);
  if (parts.length === 1 && parts[0] !== "home" && parts[0] !== "explore" && parts[0] !== "notifications" && parts[0] !== "messages" && parts[0] !== "i" && parts[0] !== "search" && parts[0] !== "settings" && parts[0] !== "compose") {
    return true;
  }
  return false;
}

// src/shared/mapping-cache.ts
var memoryCache = /* @__PURE__ */ new Map();
async function loadMappingCache() {
  memoryCache.clear();
  const storage = await chrome.storage.local.get(null);
  for (const [key, value] of Object.entries(storage)) {
    if (key.startsWith(MAPPING_CACHE.prefix)) {
      const twitterHandle = key.slice(MAPPING_CACHE.prefix.length);
      memoryCache.set(twitterHandle, value);
    }
  }
  log("CACHE", `Loaded ${memoryCache.size} mappings`);
}
function getMapping(twitterHandle) {
  return memoryCache.get(twitterHandle.toLowerCase()) ?? null;
}
async function saveMapping(mapping) {
  const key = MAPPING_CACHE.prefix + mapping.twitterHandle.toLowerCase();
  memoryCache.set(mapping.twitterHandle.toLowerCase(), mapping);
  log("CACHE", `Mapping saved: @${mapping.twitterHandle} \u2192 ${mapping.blueskyHandle}`);
  await chrome.storage.local.set({ [key]: mapping });
  await pruneIfNeeded();
}
async function pruneIfNeeded() {
  if (memoryCache.size <= MAPPING_CACHE.maxEntries) return;
  const entries = Array.from(memoryCache.entries()).sort((a, b) => a[1].discoveredAt - b[1].discoveredAt);
  const toRemove = entries.slice(0, memoryCache.size - MAPPING_CACHE.maxEntries);
  const keysToRemove = [];
  for (const [handle] of toRemove) {
    memoryCache.delete(handle);
    keysToRemove.push(MAPPING_CACHE.prefix + handle);
  }
  log("CACHE", `Mapping prune: removing ${keysToRemove.length} old entries`);
  await chrome.storage.local.remove(keysToRemove);
}
function shouldOverwriteMapping(existing, newSource) {
  const priority = { text: 3, image: 2, inferred: 1 };
  return priority[newSource] > priority[existing.source];
}

// src/shared/ocr-cache.ts
function hashImageUrl(url) {
  let hash = 0;
  for (let i = 0; i < url.length; i++) {
    const char = url.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}
function isOcrCacheStale(entry) {
  return Date.now() - entry.processedAt > OCR_CACHE.ttl;
}
async function getOcrCache(imageUrl) {
  const key = OCR_CACHE.prefix + hashImageUrl(imageUrl);
  const result = await chrome.storage.local.get(key);
  const entry = result[key];
  if (!entry) {
    log("CACHE", `OCR miss: ${imageUrl.slice(0, 60)}...`);
    return null;
  }
  if (isOcrCacheStale(entry)) {
    log("CACHE", `OCR expired: ${imageUrl.slice(0, 60)}...`);
    await chrome.storage.local.remove(key);
    return null;
  }
  return entry;
}
async function setOcrCache(imageUrl, handles) {
  const key = OCR_CACHE.prefix + hashImageUrl(imageUrl);
  log("CACHE", `OCR set: ${handles.length} handles for ${imageUrl.slice(0, 60)}...`);
  await chrome.storage.local.set({
    [key]: {
      handles,
      processedAt: Date.now()
    }
  });
  await pruneOcrCacheIfNeeded();
}
async function pruneOcrCacheIfNeeded() {
  const all = await chrome.storage.local.get(null);
  const entries = Object.entries(all).filter(([key]) => key.startsWith(OCR_CACHE.prefix)).map(([key, value]) => ({ key, ...value })).sort((a, b) => a.processedAt - b.processedAt);
  if (entries.length > OCR_CACHE.maxEntries) {
    const toRemove = entries.slice(0, entries.length - OCR_CACHE.maxEntries).map((e) => e.key);
    log("CACHE", `OCR prune: removing ${toRemove.length} old entries`);
    await chrome.storage.local.remove(toRemove);
  }
}

// src/shared/api-cache.ts
function isApiCacheStale(entry) {
  return Date.now() - entry.checkedAt > API_CACHE.ttl;
}
async function getApiCache(blueskyHandle) {
  const key = API_CACHE.prefix + blueskyHandle.toLowerCase();
  const result = await chrome.storage.local.get(key);
  const entry = result[key];
  if (!entry) {
    log("CACHE", `API miss: ${blueskyHandle}`);
    return null;
  }
  if (isApiCacheStale(entry)) {
    log("CACHE", `API expired: ${blueskyHandle}`);
    await chrome.storage.local.remove(key);
    return null;
  }
  return entry;
}
async function setApiCache(blueskyHandle, entry) {
  const key = API_CACHE.prefix + blueskyHandle.toLowerCase();
  log("CACHE", `API set: ${blueskyHandle} \u2192 exists=${entry.exists}`);
  await chrome.storage.local.set({ [key]: entry });
  await pruneApiCacheIfNeeded();
}
async function pruneApiCacheIfNeeded() {
  const all = await chrome.storage.local.get(null);
  const entries = Object.entries(all).filter(([key]) => key.startsWith(API_CACHE.prefix)).map(([key, value]) => ({ key, ...value })).sort((a, b) => a.checkedAt - b.checkedAt);
  if (entries.length > API_CACHE.maxEntries) {
    const toRemove = entries.slice(0, entries.length - API_CACHE.maxEntries).map((e) => e.key);
    log("CACHE", `API prune: removing ${toRemove.length} old entries`);
    await chrome.storage.local.remove(toRemove);
  }
}

// src/shared/handle-lookup.ts
async function lookupHandle(blueskyHandle) {
  const cached = await getApiCache(blueskyHandle);
  if (cached) {
    return cached;
  }
  log("API", `Looking up: ${blueskyHandle}`);
  try {
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.VERIFY_HANDLE,
      payload: { handle: blueskyHandle }
    });
    if (response?.error) {
      log("API", `Error looking up ${blueskyHandle}`);
      return { exists: false, displayName: null, checkedAt: Date.now() };
    }
    const entry = {
      exists: response.exists === true,
      displayName: response.displayName,
      checkedAt: Date.now()
    };
    await setApiCache(blueskyHandle, entry);
    log("API", `${blueskyHandle}: ${entry.exists ? `\u2713 ${entry.displayName || "exists"}` : "\u2717 not found"}`);
    return entry;
  } catch (error) {
    log("API", `Error looking up ${blueskyHandle}: ${error}`);
    return { exists: false, displayName: null, checkedAt: Date.now() };
  }
}

// src/content/badge-injector.ts
var BUTTERFLY_SVG = `<svg viewBox="0 0 568 501" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
<path d="M123.121 33.664C188.241 82.553 258.281 181.68 284 234.873c25.719-53.192 95.759-152.32 160.879-201.21C491.866-1.611 568-28.906 568 57.947c0 17.346-9.945 145.713-15.778 166.555-20.275 72.453-94.155 90.933-159.875 79.748C507.222 323.8 536.444 388.56 473.333 453.32c-119.86 122.992-172.272-30.859-185.702-70.281-2.462-7.227-3.614-10.608-3.631-7.733-.017-2.875-1.169.506-3.631 7.733-13.43 39.422-65.842 193.273-185.702 70.281-63.111-64.76-33.89-129.52 80.986-149.071-65.72 11.185-139.6-7.295-159.875-79.748C9.945 203.659 0 75.291 0 57.946 0-28.906 76.135-1.612 123.121 33.664Z"/>
</svg>`;
function createBadge(handle) {
  const badge = document.createElement("a");
  badge.className = "xscape-hatch-badge";
  badge.href = `${BLUESKY_API.webProfileUrl}/${handle}`;
  badge.target = "_blank";
  badge.rel = "noopener noreferrer";
  badge.setAttribute(BADGE_ATTR, "");
  badge.setAttribute("data-handle", handle);
  badge.setAttribute("data-verified", "true");
  badge.innerHTML = `${BUTTERFLY_SVG}<span>@${handle}</span>`;
  return badge;
}
function badgeExistsFor(handle, container) {
  return container.querySelector(`.xscape-hatch-badge[data-handle="${handle}"]`) !== null;
}
function injectBadge(badge, targetElement) {
  const parent = targetElement.parentElement;
  const grandparent = parent?.parentElement;
  if (grandparent) {
    const grandparentStyle = window.getComputedStyle(grandparent);
    if (grandparentStyle.display === "flex" && grandparentStyle.flexDirection === "row") {
      grandparent.insertBefore(badge, parent);
      return;
    }
  }
  if (parent) {
    parent.insertBefore(badge, targetElement);
  }
}
function createProfileBadge(handle) {
  const badge = createBadge(handle);
  badge.classList.add("xscape-hatch-badge--profile");
  return badge;
}
function injectProfileBadge(badge, handleElement) {
  const parent = handleElement.parentElement;
  if (parent) {
    parent.insertBefore(badge, handleElement.nextSibling);
  }
}

// src/content/content.ts
var ocrQueue = [];
var ocrProcessing = false;
var lastProcessedProfileHandle = null;
var lastUrl = window.location.href;
async function init() {
  await initDebug();
  exposeDebugGlobal();
  await loadMappingCache();
  const observer = createDOMObserver(onTweetFound);
  observer.start();
  watchForNavigation();
  setTimeout(processProfileHeader, 500);
  log("DOM", "Initialized and watching for tweets");
}
function watchForNavigation() {
  const observer = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      lastProcessedProfileHandle = null;
      setTimeout(processProfileHeader, 500);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
async function processProfileHeader() {
  if (!isProfilePage()) return;
  const header = extractProfileHeader();
  if (!header) {
    setTimeout(processProfileHeader, 500);
    return;
  }
  if (lastProcessedProfileHandle === header.twitterHandle) return;
  const existing = getMapping(header.twitterHandle);
  if (existing) {
    if (!badgeExistsFor(existing.blueskyHandle, header.handleElement.parentElement)) {
      log("BADGE", `Injecting profile badge: @${header.twitterHandle} \u2192 ${existing.blueskyHandle}`);
      const badge = createProfileBadge(existing.blueskyHandle);
      injectProfileBadge(badge, header.handleElement);
      lastProcessedProfileHandle = header.twitterHandle;
    }
    return;
  }
  const inferredHandle = `${header.twitterHandle.toLowerCase()}.bsky.social`;
  const result = await lookupHandle(inferredHandle);
  if (result.exists) {
    const mapping = {
      twitterHandle: header.twitterHandle.toLowerCase(),
      blueskyHandle: inferredHandle,
      displayName: result.displayName,
      source: "inferred",
      discoveredAt: Date.now()
    };
    await saveMapping(mapping);
    log("BADGE", `Injecting profile badge: @${header.twitterHandle} \u2192 ${inferredHandle}`);
    const badge = createProfileBadge(inferredHandle);
    injectProfileBadge(badge, header.handleElement);
    lastProcessedProfileHandle = header.twitterHandle;
  }
}
async function processOCRQueue() {
  if (ocrProcessing || ocrQueue.length === 0) return;
  ocrProcessing = true;
  const { imageUrl, twitterHandle } = ocrQueue.shift();
  log("OCR", `Processing image for @${twitterHandle} (queue: ${ocrQueue.length})`);
  try {
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.OCR_PROCESS,
      payload: { imageUrl, requestId: `ocr-${Date.now()}` }
    });
    log("OCR", `Response for @${twitterHandle}: ${JSON.stringify(response)}`);
    const handles = response?.handles || [];
    await setOcrCache(imageUrl, handles);
    if (handles.length > 0) {
      log("OCR", `Found: ${handles.join(", ")}`);
      for (const blueskyHandle of handles) {
        await processDiscoveredHandle(twitterHandle, blueskyHandle, "image");
      }
    }
  } catch (error) {
    log("OCR", `Error: ${error}`);
  }
  ocrProcessing = false;
  processOCRQueue();
}
async function queueImageForOCR(imageUrl, twitterHandle) {
  const cached = await getOcrCache(imageUrl);
  if (cached) {
    for (const handle of cached.handles) {
      await processDiscoveredHandle(twitterHandle, handle, "image");
    }
    return;
  }
  if (ocrQueue.length < 20) {
    ocrQueue.push({ imageUrl, twitterHandle });
    processOCRQueue();
  }
}
async function processDiscoveredHandle(twitterHandle, blueskyHandle, source) {
  const existing = getMapping(twitterHandle);
  if (existing && !shouldOverwriteMapping(existing, source)) {
    return;
  }
  const result = await lookupHandle(blueskyHandle);
  if (!result.exists) {
    return;
  }
  const mapping = {
    twitterHandle: twitterHandle.toLowerCase(),
    blueskyHandle: blueskyHandle.toLowerCase(),
    displayName: result.displayName,
    source,
    discoveredAt: Date.now()
  };
  log("CACHE", `@${twitterHandle} \u2192 ${blueskyHandle} (${source}) - verified`);
  await saveMapping(mapping);
  refreshBadgesForTwitterHandle(twitterHandle, mapping);
}
function refreshBadgesForTwitterHandle(twitterHandle, mapping) {
  const articles = document.querySelectorAll("article");
  for (const article of articles) {
    if (badgeExistsFor(mapping.blueskyHandle, article)) continue;
    const authorLinks = article.querySelectorAll('a[href^="/"]');
    let handleTextLink = null;
    let profileImageLink = null;
    for (const link of authorLinks) {
      const href = link.getAttribute("href");
      if (!href) continue;
      const pathPart = href.slice(1).split("/")[0].split("?")[0];
      if (pathPart.toLowerCase() !== twitterHandle.toLowerCase()) continue;
      const text = (link.textContent || "").trim();
      if (text.startsWith("@") && /^@[a-zA-Z0-9_]{1,15}$/.test(text)) {
        handleTextLink = link;
        break;
      }
      if (!profileImageLink && link.querySelector('img[src*="profile_images"]')) {
        profileImageLink = link;
      }
    }
    const targetLink = handleTextLink || profileImageLink;
    if (targetLink) {
      log("BADGE", `Injecting badge: @${twitterHandle} \u2192 ${mapping.blueskyHandle}`);
      const badge = createBadge(mapping.blueskyHandle);
      injectBadge(badge, targetLink);
      if (handleTextLink) {
        handleTextLink.style.display = "none";
      }
    }
  }
}
function onTweetFound({ article, author, blueskyHandles, images }) {
  if (!author) return;
  const existingMapping = getMapping(author.twitterHandle);
  if (existingMapping) {
    if (!badgeExistsFor(existingMapping.blueskyHandle, article)) {
      log("BADGE", `Injecting badge: @${author.twitterHandle} \u2192 ${existingMapping.blueskyHandle}`);
      const badge = createBadge(existingMapping.blueskyHandle);
      injectBadge(badge, author.authorElement);
      const text = (author.authorElement.textContent || "").trim();
      if (text.startsWith("@") && /^@[a-zA-Z0-9_]{1,15}$/.test(text)) {
        author.authorElement.style.display = "none";
      }
    }
    return;
  }
  if (blueskyHandles.length > 0) {
    processDiscoveredHandle(author.twitterHandle, blueskyHandles[0], "text");
  }
  images.forEach((imageData) => {
    const imageAuthor = getImageAuthor(imageData.element);
    const targetAuthor = imageAuthor || author.twitterHandle;
    queueImageForOCR(imageData.url, targetAuthor);
  });
  if (blueskyHandles.length === 0) {
    const inferredHandle = `${author.twitterHandle.toLowerCase()}.bsky.social`;
    processDiscoveredHandle(author.twitterHandle, inferredHandle, "inferred");
  }
}
init();
//# sourceMappingURL=content.js.map
