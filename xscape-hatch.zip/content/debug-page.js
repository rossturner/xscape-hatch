// src/content/debug-page.ts
window.xscapeDebug = function(enabled) {
  if (enabled === void 0) {
    document.dispatchEvent(new CustomEvent("xscape-debug-query"));
    return;
  }
  document.dispatchEvent(new CustomEvent("xscape-debug-set", { detail: enabled }));
  console.log(`[Xscape] Debug ${enabled ? "enabled" : "disabled"}`);
  return enabled;
};
window.xscapeClearCaches = function() {
  const handler = ((event) => {
    console.log(`[Xscape] Cleared ${event.detail} cache entries`);
    document.removeEventListener("xscape-caches-cleared", handler);
  });
  document.addEventListener("xscape-caches-cleared", handler);
  document.dispatchEvent(new CustomEvent("xscape-clear-caches"));
};
//# sourceMappingURL=debug-page.js.map
