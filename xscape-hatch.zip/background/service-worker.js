// src/shared/constants.ts
var BLUESKY_API = {
  profileUrl: "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile",
  webProfileUrl: "https://bsky.app/profile"
};
var API_CACHE = {
  prefix: "xscape:api:",
  ttl: 24 * 60 * 60 * 1e3,
  // 24 hours
  maxEntries: 1e4
};
var OCR_CACHE = {
  prefix: "xscape:ocr:",
  ttl: 7 * 24 * 60 * 60 * 1e3,
  // 7 days
  maxEntries: 1e4
};
var MESSAGE_TYPES = {
  VERIFY_HANDLE: "VERIFY_HANDLE",
  HANDLE_VERIFIED: "HANDLE_VERIFIED",
  OCR_INIT: "OCR_INIT",
  OCR_READY: "OCR_READY",
  OCR_PROCESS: "OCR_PROCESS",
  OCR_PROCESS_INTERNAL: "OCR_PROCESS_INTERNAL",
  OCR_RESULT: "OCR_RESULT",
  DEBUG_TOGGLE: "DEBUG_TOGGLE"
};

// src/shared/debug.ts
var STORAGE_KEY = "xscape:debug";
var debugEnabled = false;
async function initDebug() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  debugEnabled = result[STORAGE_KEY] === true;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      debugEnabled = changes[STORAGE_KEY].newValue === true;
      log("MSG", `Debug ${debugEnabled ? "enabled" : "disabled"}`);
    }
  });
}
function log(category, message, ...data) {
  if (!debugEnabled) return;
  const prefix = `[Xscape:${category}]`;
  if (data.length > 0) {
    console.log(prefix, message, ...data);
  } else {
    console.log(prefix, message);
  }
}
function isDebugEnabled() {
  return debugEnabled;
}
async function setDebugEnabled(enabled) {
  await chrome.storage.local.set({ [STORAGE_KEY]: enabled });
}
async function clearAllCaches() {
  const prefixes = ["xscape:api:", "xscape:ocr:", "xscape:mapping:"];
  const all = await chrome.storage.local.get(null);
  const keysToRemove = Object.keys(all).filter(
    (key) => prefixes.some((prefix) => key.startsWith(prefix))
  );
  if (keysToRemove.length > 0) {
    await chrome.storage.local.remove(keysToRemove);
  }
  return keysToRemove.length;
}
function exposeDebugGlobal() {
  if (typeof document === "undefined") return;
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("content/debug-page.js");
  script.type = "module";
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
  document.addEventListener("xscape-debug-set", ((event) => {
    setDebugEnabled(event.detail === true);
  }));
  document.addEventListener("xscape-debug-query", () => {
    console.log(`[Xscape] Debug is ${debugEnabled ? "ON" : "OFF"}`);
  });
  document.addEventListener("xscape-clear-caches", async () => {
    const count = await clearAllCaches();
    document.dispatchEvent(new CustomEvent("xscape-caches-cleared", { detail: count }));
  });
}

// src/background/cache.ts
async function getCachedHandle(handle) {
  const key = API_CACHE.prefix + handle;
  const result = await chrome.storage.local.get(key);
  const entry = result[key];
  if (!entry) {
    log("CACHE", `Miss: ${handle}`);
    return null;
  }
  if (Date.now() - entry.checkedAt > API_CACHE.ttl) {
    log("CACHE", `Expired: ${handle}`);
    await chrome.storage.local.remove(key);
    return null;
  }
  log("CACHE", `Hit: ${handle} \u2192 exists=${entry.exists}`);
  return entry;
}
async function setCachedHandle(handle, exists, displayName = null) {
  const key = API_CACHE.prefix + handle;
  log("CACHE", `Set: ${handle} \u2192 exists=${exists}`);
  await chrome.storage.local.set({
    [key]: {
      exists,
      displayName,
      checkedAt: Date.now()
    }
  });
}
async function pruneCache(maxEntries = API_CACHE.maxEntries) {
  const all = await chrome.storage.local.get(null);
  const entries = Object.entries(all).filter(([key]) => key.startsWith(API_CACHE.prefix)).map(([key, value]) => ({ key, ...value })).sort((a, b) => a.checkedAt - b.checkedAt);
  if (entries.length > maxEntries) {
    const toRemove = entries.slice(0, entries.length - maxEntries).map((e) => e.key);
    log("CACHE", `Pruning ${toRemove.length} old entries`);
    await chrome.storage.local.remove(toRemove);
  }
}

// src/background/bluesky-api.ts
async function verifyBlueskyProfile(handle) {
  try {
    const url = `${BLUESKY_API.profileUrl}?actor=${encodeURIComponent(handle)}`;
    log("API", `Fetching profile: ${handle}`);
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      log("API", `Profile found: ${handle} \u2192 displayName=${data.displayName ?? "none"}`);
      return {
        exists: true,
        displayName: data.displayName || null
      };
    }
    if (response.status === 400) {
      log("API", `Profile not found: ${handle}`);
      return { exists: false, displayName: null };
    }
    log("API", `Unexpected response for ${handle}: ${response.status}`);
    return null;
  } catch (error) {
    log("API", `Error fetching ${handle}`, error);
    console.error("Xscape Hatch: API error", error);
    return null;
  }
}

// src/background/service-worker.ts
var OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
var creatingOffscreenDocument = null;
async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  return contexts.length > 0;
}
async function setupOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    return;
  }
  if (creatingOffscreenDocument) {
    await creatingOffscreenDocument;
    return;
  }
  try {
    creatingOffscreenDocument = chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: [chrome.offscreen.Reason.WORKERS],
      justification: "OCR processing with Tesseract.js web worker"
    });
    await creatingOffscreenDocument;
    creatingOffscreenDocument = null;
    log("MSG", "Offscreen document created");
  } catch (error) {
    creatingOffscreenDocument = null;
    throw error;
  }
}
async function processOCR(imageUrl, requestId) {
  console.log("[Xscape:SW] processOCR starting for:", imageUrl.slice(0, 60));
  await setupOffscreenDocument();
  console.log("[Xscape:SW] Offscreen document ready, sending OCR_PROCESS_INTERNAL");
  try {
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPES.OCR_PROCESS_INTERNAL,
      payload: { imageUrl, requestId }
    });
    console.log("[Xscape:SW] Got OCR response:", response);
    return response?.handles || [];
  } catch (error) {
    console.error("[Xscape:SW] OCR error:", error);
    return [];
  }
}
var CONTEXT_MENU_ID = "xscape-debug-toggle";
async function initContextMenu() {
  const enabled = isDebugEnabled();
  chrome.contextMenus.create({
    id: CONTEXT_MENU_ID,
    title: `Xscape Hatch: Debug ${enabled ? "ON \u2713" : "OFF"}`,
    contexts: ["page"],
    documentUrlPatterns: ["https://x.com/*", "https://twitter.com/*"]
  });
}
async function updateContextMenuTitle() {
  const enabled = isDebugEnabled();
  chrome.contextMenus.update(CONTEXT_MENU_ID, {
    title: `Xscape Hatch: Debug ${enabled ? "ON \u2713" : "OFF"}`
  });
}
chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId === CONTEXT_MENU_ID) {
    const newState = !isDebugEnabled();
    await setDebugEnabled(newState);
    await updateContextMenuTitle();
    log("MSG", `Debug toggled via context menu: ${newState}`);
  }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes["xscape:debug"]) {
    updateContextMenuTitle();
  }
});
var pendingVerifications = /* @__PURE__ */ new Map();
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    if (message.type === MESSAGE_TYPES.VERIFY_HANDLE && message.payload.handle) {
      log("MSG", `Received VERIFY_HANDLE for ${message.payload.handle}`);
      handleVerification(message.payload.handle, sender.tab?.id).then(sendResponse);
      return true;
    }
    if (message.type === MESSAGE_TYPES.OCR_PROCESS && message.payload.imageUrl && message.payload.requestId) {
      log("MSG", `Received OCR_PROCESS for ${message.payload.imageUrl.slice(0, 50)}...`);
      processOCR(message.payload.imageUrl, message.payload.requestId).then((handles) => {
        sendResponse({ handles });
      });
      return true;
    }
    if (message.type === MESSAGE_TYPES.DEBUG_TOGGLE) {
      const enabled = message.payload.enabled ?? !isDebugEnabled();
      setDebugEnabled(enabled).then(() => {
        log("MSG", `Debug toggled via message: ${enabled}`);
        sendResponse({ enabled });
      });
      return true;
    }
    return false;
  }
);
async function handleVerification(handle, _tabId) {
  const cached = await getCachedHandle(handle);
  if (cached !== null) {
    return { handle, exists: cached.exists, displayName: cached.displayName };
  }
  if (pendingVerifications.has(handle)) {
    return pendingVerifications.get(handle);
  }
  log("API", `Verifying handle: ${handle}`);
  const verificationPromise = (async () => {
    const result = await verifyBlueskyProfile(handle);
    if (result !== null) {
      log("API", `Verification result: ${handle} \u2192 exists=${result.exists}, displayName=${result.displayName}`);
      await setCachedHandle(handle, result.exists, result.displayName);
      pendingVerifications.delete(handle);
      return { handle, exists: result.exists, displayName: result.displayName };
    }
    log("API", `Verification error: ${handle}`);
    pendingVerifications.delete(handle);
    return { handle, exists: null, displayName: null, error: true };
  })();
  pendingVerifications.set(handle, verificationPromise);
  return verificationPromise;
}
chrome.runtime.onInstalled.addListener(async () => {
  await initDebug();
  await initContextMenu();
  pruneCache();
  log("MSG", "Extension installed/updated");
});
chrome.runtime.onStartup.addListener(async () => {
  await initDebug();
  await initContextMenu();
  log("MSG", "Service worker started");
});
initDebug().then(() => {
  exposeDebugGlobal();
  log("MSG", "Service worker initialized");
});
//# sourceMappingURL=service-worker.js.map
